<?php

$hostname = "localhost";
$username = "root";
$password = "";
$database = "login_register_laundry_2";

$conn = mysqli_connect($hostname, $username, $password, $database) or die("Database connection failed");

$base_url = "https://code.akhfasoft.net/login-register-youtube/";
$my_email = "code@akhfasoft.net";

?>