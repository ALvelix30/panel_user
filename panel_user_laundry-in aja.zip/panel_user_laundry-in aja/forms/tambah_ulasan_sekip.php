<?php

session_start();
$conn = mysqli_connect("localhost", "root", "", "laundry_a");

if (isset($_POST['ulasan'])) {
    $name = $_POST['name'];
    $gmail = $_POST['gmail'];
    $message = $_POST['message'];
    $skor = $_POST['skor'];
    $tanggal = date('Y-m-d', strtotime($_POST['tanggal']));

    $query = "INSERT INTO ulasan_pelanggan (name,gmail,message,skor,tanggal) VALUES ('$name','$gmail','$message','$skor','$tanggal')";
    $query_run = mysqli_query($conn, $query);

    if ($query_run) {
        $_SESSION['status'] = "Sukses Menambahkan Ulasan";
        header("Location: ../laundry_sekip.php");
    } else {
        $_SESSION['status'] = "Gagal Menambahkan Data Ulasan";
        header("Location: ../laundry_sekip.php");
    }
}